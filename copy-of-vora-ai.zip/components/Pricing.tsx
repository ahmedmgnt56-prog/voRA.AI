
import React, { useState } from 'react';
import { Check, Zap, Shield, Crown, CreditCard, Apple, Smartphone, ArrowRight, Loader2 } from 'lucide-react';
import { UserTier } from '../types';

interface PricingProps {
  currentTier: UserTier;
  onUpgrade: (tier: UserTier) => void;
}

const Pricing: React.FC<PricingProps> = ({ currentTier, onUpgrade }) => {
  const [selectedPlan, setSelectedPlan] = useState<UserTier | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  const plans = [
    {
      id: UserTier.FREE,
      name: 'Alpha',
      price: '$0',
      description: 'Test the neural engine core.',
      icon: <Zap className="text-slate-400" />,
      features: ['1 Neural Clip / Video', 'Standard Processing', 'Vora Branding', '720p Quality'],
      buttonText: 'Current Plan',
      highlight: false
    },
    {
      id: UserTier.PRO,
      name: 'Velocity',
      price: '$29',
      description: 'Master the algorithm at scale.',
      icon: <Crown className="text-purple-400" />,
      features: ['Unlimited Clipping', 'Deep Strategy Lab', 'No Watermarks', '4K Neural Render', 'Priority Nodes'],
      buttonText: 'Unlock Velocity',
      highlight: true
    },
    {
      id: UserTier.ENTERPRISE,
      name: 'Omni',
      price: '$99',
      description: 'Global content domination.',
      icon: <Shield className="text-cyan-400" />,
      features: ['API Direct Bridge', 'Team Workspace', 'Voice Cloning Lab', 'White-label Output', 'Dedicated Node'],
      buttonText: 'Contact Sales',
      highlight: false
    }
  ];

  const handleCheckout = (tier: UserTier) => {
    setIsProcessing(true);
    setTimeout(() => {
      onUpgrade(tier);
      setIsProcessing(false);
    }, 2000);
  };

  if (selectedPlan && selectedPlan !== UserTier.FREE) {
    return (
      <div className="flex flex-col items-center justify-center min-h-full p-6 animate-in fade-in zoom-in duration-300">
        <div className="max-w-md w-full glass p-8 md:p-10 rounded-[2.5rem] border border-white/10">
          <button onClick={() => setSelectedPlan(null)} className="text-slate-500 mb-8 hover:text-white transition-colors text-sm">← Back to plans</button>
          <h2 className="text-2xl font-bold mb-2">Finalize Subscription</h2>
          <p className="text-slate-400 text-sm mb-8">You've selected the <span className="text-purple-400 font-bold">{selectedPlan}</span> plan.</p>
          
          <div className="space-y-3 mb-10">
            <button onClick={() => handleCheckout(selectedPlan)} className="w-full flex items-center justify-between p-4 bg-white/5 border border-white/10 rounded-2xl hover:bg-white/10 transition-all">
               <div className="flex items-center gap-3">
                 <Apple size={20} />
                 <span className="font-bold">Apple Pay</span>
               </div>
               <ArrowRight size={16} className="text-slate-500" />
            </button>
            <button onClick={() => handleCheckout(selectedPlan)} className="w-full flex items-center justify-between p-4 bg-white/5 border border-white/10 rounded-2xl hover:bg-white/10 transition-all">
               <div className="flex items-center gap-3">
                 <Smartphone size={20} className="text-cyan-400" />
                 <span className="font-bold">Google Pay</span>
               </div>
               <ArrowRight size={16} className="text-slate-500" />
            </button>
            <button onClick={() => handleCheckout(selectedPlan)} className="w-full flex items-center justify-between p-4 bg-white/5 border border-white/10 rounded-2xl hover:bg-white/10 transition-all">
               <div className="flex items-center gap-3">
                 <CreditCard size={20} className="text-purple-400" />
                 <span className="font-bold">Card Ending in 4242</span>
               </div>
               <ArrowRight size={16} className="text-slate-500" />
            </button>
          </div>

          <p className="text-[10px] text-slate-500 text-center leading-relaxed">
            By subscribing, you agree to Vora's Terms of Service. Your card will be charged monthly. Cancel anytime via the dashboard.
          </p>

          {isProcessing && (
            <div className="absolute inset-0 bg-slate-950/90 rounded-[2.5rem] flex flex-col items-center justify-center">
              <Loader2 className="animate-spin text-purple-500 mb-4" size={32} />
              <p className="text-sm font-bold tracking-widest uppercase">Validating Node...</p>
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center justify-center min-h-full p-6 py-12">
      <div className="text-center mb-12">
        <h1 className="text-3xl md:text-5xl font-extrabold mb-4">Master Your <span className="brand-accent">Presence</span></h1>
        <p className="text-slate-400 text-sm md:text-base">Scale your distribution with Vora's high-velocity nodes.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 w-full max-w-6xl">
        {plans.map((plan) => (
          <div 
            key={plan.id}
            className={`glass p-8 rounded-[2rem] border flex flex-col relative transition-all duration-500 hover:translate-y-[-4px] ${
              plan.highlight ? 'border-purple-500/30 ring-1 ring-purple-500/20' : 'border-white/5'
            }`}
          >
            {plan.highlight && (
              <div className="absolute -top-3 left-1/2 -translate-x-1/2 brand-gradient text-white text-[10px] font-bold px-4 py-1 rounded-full uppercase tracking-widest">
                Recommended
              </div>
            )}
            
            <div className="mb-6 flex items-center justify-between">
              <div className="w-12 h-12 rounded-2xl bg-white/5 flex items-center justify-center">
                {plan.icon}
              </div>
              <div className="text-right">
                <span className="text-3xl font-bold tracking-tighter">{plan.price}</span>
                <span className="text-slate-500 text-xs font-semibold">/mo</span>
              </div>
            </div>

            <h3 className="text-xl font-bold mb-2">{plan.name}</h3>
            <p className="text-slate-500 text-xs mb-8">{plan.description}</p>

            <div className="space-y-4 mb-10 flex-1">
              {plan.features.map((feature, i) => (
                <div key={i} className="flex items-center gap-3 text-xs">
                  <div className="w-5 h-5 rounded-full bg-green-500/10 flex items-center justify-center shrink-0">
                    <Check size={12} className="text-green-500" />
                  </div>
                  <span className="text-slate-300">{feature}</span>
                </div>
              ))}
            </div>

            <button 
              onClick={() => plan.id !== UserTier.FREE && setSelectedPlan(plan.id)}
              disabled={currentTier === plan.id}
              className={`w-full py-4 rounded-xl font-bold transition-all ${
                plan.highlight 
                  ? 'brand-gradient text-white shadow-xl shadow-purple-500/10 hover:brightness-110' 
                  : 'bg-white/5 text-slate-300 hover:bg-white/10 disabled:opacity-30'
              }`}
            >
              {currentTier === plan.id ? 'Active Node' : plan.buttonText}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Pricing;
