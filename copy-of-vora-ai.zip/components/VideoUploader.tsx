
import React, { useState, useEffect } from 'react';
import { Upload, Zap, Link as LinkIcon, ArrowRight, Youtube, Instagram, Music2 } from 'lucide-react';

interface VideoUploaderProps {
  onUpload: (file: File) => void;
  onUrlSubmit: (url: string) => void;
}

const VideoUploader: React.FC<VideoUploaderProps> = ({ onUpload, onUrlSubmit }) => {
  const [url, setUrl] = useState('');
  const [detectedPlatform, setDetectedPlatform] = useState<'youtube' | 'instagram' | 'tiktok' | 'generic' | null>(null);

  useEffect(() => {
    const lowerUrl = url.toLowerCase();
    if (lowerUrl.includes('youtube.com') || lowerUrl.includes('youtu.be')) setDetectedPlatform('youtube');
    else if (lowerUrl.includes('instagram.com')) setDetectedPlatform('instagram');
    else if (lowerUrl.includes('tiktok.com')) setDetectedPlatform('tiktok');
    else if (url.trim() !== '') setDetectedPlatform('generic');
    else setDetectedPlatform(null);
  }, [url]);

  const handleUrlSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (url.trim()) onUrlSubmit(url.trim());
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-[calc(100vh-64px)] md:min-h-full p-6 md:p-12 animate-in fade-in duration-1000">
      <div className="max-w-4xl w-full">
        <div className="flex items-center gap-4 mb-8 md:mb-12">
          <div className="px-4 py-1.5 glass border border-white/5 rounded-full text-[10px] font-bold text-purple-400 uppercase tracking-widest">
            Neural Extraction v2.5
          </div>
          <div className="flex-1 h-px bg-white/5" />
        </div>

        <h1 className="text-4xl md:text-7xl font-extrabold mb-6 tracking-tight leading-[1.1]">
          Vora <span className="brand-accent">consumes</span> content.<br />
          You <span className="text-cyan-400">master</span> the feed.
        </h1>
        
        <p className="text-slate-400 text-lg md:text-xl mb-10 md:mb-16 max-w-2xl leading-relaxed">
          The elite AI engine for high-velocity clippers. We don't just find clips—we identify viral DNA.
        </p>

        <div className="glass p-1.5 rounded-2xl md:rounded-[2.5rem] border border-white/10 mb-10 shadow-2xl focus-within:ring-2 ring-purple-500/20 transition-all">
          <form onSubmit={handleUrlSubmit} className="flex flex-col md:flex-row items-center gap-2">
            <div className="w-full flex items-center bg-transparent border-none py-4 px-4">
              <div className="shrink-0 text-slate-500 mr-4">
                {detectedPlatform === 'youtube' ? <Youtube size={22} className="text-red-500" /> :
                 detectedPlatform === 'instagram' ? <Instagram size={22} className="text-pink-500" /> :
                 detectedPlatform === 'tiktok' ? <Music2 size={22} className="text-cyan-400" /> :
                 <LinkIcon size={22} />}
              </div>
              <input 
                type="text" 
                placeholder="Paste YouTube, TikTok or IG link..."
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                className="flex-1 bg-transparent border-none text-base md:text-lg focus:outline-none placeholder:text-slate-600 font-medium"
              />
            </div>
            <button 
              type="submit"
              disabled={!url.trim()}
              className="w-full md:w-auto md:mr-1 brand-gradient text-white px-8 py-4 rounded-xl md:rounded-[2rem] font-bold flex items-center justify-center gap-3 hover:brightness-110 active:scale-95 disabled:opacity-30 transition-all"
            >
              Analyze
              <ArrowRight size={20} />
            </button>
          </form>
        </div>

        <div className="flex flex-col md:flex-row items-center gap-8 opacity-60">
          <label className="flex items-center gap-3 cursor-pointer group">
            <div className="w-10 h-10 rounded-xl bg-slate-900 flex items-center justify-center group-hover:bg-slate-800 transition-all">
              <Upload size={18} className="text-slate-400" />
            </div>
            <span className="text-sm font-semibold group-hover:text-white">Manual Upload</span>
            <input type="file" className="hidden" accept="video/*" onChange={(e) => e.target.files?.[0] && onUpload(e.target.files[0])} />
          </label>
          <div className="hidden md:block h-4 w-px bg-white/10" />
          <div className="flex gap-6 items-center grayscale hover:grayscale-0 transition-all">
             <Youtube size={18} />
             <Instagram size={18} />
             <Music2 size={18} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default VideoUploader;
