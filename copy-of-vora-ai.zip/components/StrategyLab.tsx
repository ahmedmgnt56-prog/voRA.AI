
import React from 'react';
import { Target, DollarSign, Share2, Lightbulb, ArrowLeft, TrendingUp, Zap, ChevronRight } from 'lucide-react';
import { Clip } from '../types';

interface StrategyLabProps {
  clip: Clip;
  onBack: () => void;
}

const StrategyLab: React.FC<StrategyLabProps> = ({ clip, onBack }) => {
  const playbooks = [
    {
      platform: 'TikTok / IG Reels',
      hook: 'Pattern Interrupt',
      strategy: 'Use a "Hook Overlay" for the first 2 seconds. Pair with high-velocity trending audio.',
      roi: 'High'
    },
    {
      platform: 'YouTube Shorts',
      hook: 'SEO Optimization',
      strategy: 'Direct viewers to a pinned affiliate link in the comment section for 12% boost.',
      roi: 'Stable'
    }
  ];

  return (
    <div className="p-4 md:p-10 max-w-6xl mx-auto animate-in fade-in zoom-in duration-500">
      <button onClick={onBack} className="flex items-center gap-2 text-slate-500 hover:text-white mb-8 md:mb-12 transition-all text-sm font-medium">
        <ArrowLeft size={18} /> Back to Studio
      </button>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 md:gap-10">
        <div className="lg:col-span-2 space-y-8 md:space-y-12">
          <header>
            <h1 className="text-3xl md:text-5xl font-black mb-4 tracking-tighter">Monetization <span className="brand-accent">Playbook</span></h1>
            <p className="text-slate-400 text-sm md:text-base leading-relaxed">Vora identified high-yield triggers in <span className="text-white font-bold underline decoration-purple-500/30 underline-offset-4">"{clip.title}"</span>.</p>
          </header>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
            {playbooks.map((p, i) => (
              <div key={i} className="glass p-6 rounded-[2rem] border border-white/5 group hover:border-purple-500/20 transition-all">
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center text-purple-400">
                      <Share2 size={16} />
                    </div>
                    <span className="text-sm font-bold">{p.platform}</span>
                  </div>
                  <span className="text-[10px] font-black uppercase text-cyan-400 tracking-widest">{p.roi} ROI</span>
                </div>
                <div className="space-y-4">
                  <div>
                    <p className="text-[10px] font-black uppercase text-slate-500 mb-1 tracking-widest">Hook Archetype</p>
                    <p className="text-sm font-semibold">{p.hook}</p>
                  </div>
                  <div>
                    <p className="text-[10px] font-black uppercase text-slate-500 mb-1 tracking-widest">Vora Execution</p>
                    <p className="text-xs text-slate-400 leading-relaxed">{p.strategy}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="glass p-6 md:p-10 rounded-[2.5rem] border border-white/5 bg-gradient-to-br from-purple-500/[0.03] to-transparent">
            <h3 className="text-lg font-bold mb-6 flex items-center gap-3">
              <Lightbulb className="text-purple-400" /> Neural Suggestion
            </h3>
            <div className="p-6 bg-black/40 rounded-2xl border border-white/5">
              <p className="text-sm text-slate-300 italic leading-relaxed">
                "Content context suggests high conversion for <span className="text-purple-400 font-bold">digital assets</span>. Link to your private community or Whop shop in the bio for maximum retention conversion."
              </p>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <div className="glass p-8 rounded-[2.5rem] border border-purple-500/20 bg-gradient-to-b from-purple-500/[0.02] to-transparent shadow-2xl">
            <h4 className="text-[10px] font-black uppercase tracking-widest text-slate-500 mb-8">Node Projection</h4>
            <div className="space-y-10">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-slate-900 border border-white/5 flex items-center justify-center shadow-inner">
                    <Target className="text-purple-400" size={24} />
                  </div>
                  <div>
                    <p className="text-[10px] text-slate-500 uppercase font-black tracking-widest">Neural Reach</p>
                    <p className="text-xl font-black">40k - 180k</p>
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-slate-900 border border-white/5 flex items-center justify-center">
                    <DollarSign className="text-cyan-400" size={24} />
                  </div>
                  <div>
                    <p className="text-[10px] text-slate-500 uppercase font-black tracking-widest">Est. Conversion</p>
                    <p className="text-2xl font-black text-cyan-400">$620.00</p>
                  </div>
                </div>
                <Zap size={20} className="text-purple-400 animate-pulse" />
              </div>
            </div>
            
            <button className="w-full mt-10 py-5 brand-gradient rounded-2xl font-black text-white hover:brightness-110 transition-all flex items-center justify-center gap-2 group">
              Master the Algorithm <ChevronRight size={18} className="group-hover:translate-x-1 transition-transform" />
            </button>
          </div>

          <div className="p-6 border border-white/5 rounded-2xl space-y-4">
            <h5 className="text-[10px] font-black text-slate-500 uppercase tracking-widest">High-Frequency Tags</h5>
            <div className="flex flex-wrap gap-2">
              {['ViralHook', 'Algorithmic', 'VoraAI', 'RevenueGen'].map(tag => (
                <span key={tag} className="text-[10px] font-bold bg-white/5 text-slate-400 px-3 py-1.5 rounded-lg border border-white/5">
                  #{tag}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StrategyLab;
