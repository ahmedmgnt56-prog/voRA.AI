
import React, { useState, useRef } from 'react';
import { 
  Play, Pause, Share, Download, Sparkles, TrendingUp, 
  CheckCircle2, Crown, ChevronRight, Youtube, Instagram, Music2, Target,
  Zap, Search, MessageSquare, Loader2, ExternalLink, RefreshCw, Copy, Settings2
} from 'lucide-react';
import { Clip } from '../types';
import { GeminiService } from '../services/geminiService';

interface ClipEditorProps {
  videoUrl: string;
  clips: Clip[];
  onExport: (clip: Clip) => void;
  onOpenStrategy: (clip: Clip) => void;
}

const ClipEditor: React.FC<ClipEditorProps> = ({ videoUrl, clips, onExport, onOpenStrategy }) => {
  const [selectedClip, setSelectedClip] = useState<Clip | null>(clips[0] || null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isSearching, setIsSearching] = useState(false);
  const [activeTab, setActiveTab] = useState<'tiktok' | 'reels' | 'shorts'>('tiktok');
  const [customGuidance, setCustomGuidance] = useState('');
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const geminiRef = useRef<GeminiService>(new GeminiService());

  const togglePlay = () => {
    if (videoRef.current) {
      if (isPlaying) videoRef.current.pause();
      else videoRef.current.play();
      setIsPlaying(!isPlaying);
    }
  };

  const handleClipSelect = (clip: Clip) => {
    setSelectedClip(clip);
    if (videoRef.current) {
      videoRef.current.currentTime = clip.startTime;
      videoRef.current.play();
      setIsPlaying(true);
    }
  };

  const handleGenerateCaptions = async () => {
    if (!selectedClip) return;
    setIsGenerating(true);
    try {
      const trends = selectedClip.nicheInsights || ["Fast paced editing", "Value-first hooks"];
      const captions = await geminiRef.current.generateOptimizedCaptions(selectedClip, trends, customGuidance);
      setSelectedClip(prev => prev ? { ...prev, generatedCaptions: captions } : null);
    } catch (error) {
      console.error(error);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleViralPulse = async () => {
    if (!selectedClip) return;
    setIsSearching(true);
    try {
      const { insights } = await geminiRef.current.searchViralNiche(selectedClip.title, selectedClip.description);
      setSelectedClip(prev => prev ? { ...prev, nicheInsights: insights } : null);
    } catch (error) {
      console.error(error);
    } finally {
      setIsSearching(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  const renderPlatformIcon = (platform: string) => {
    const p = platform.toLowerCase();
    if (p.includes('youtube')) return <Youtube key={platform} size={12} className="text-red-500" />;
    if (p.includes('instagram')) return <Instagram key={platform} size={12} className="text-pink-500" />;
    if (p.includes('tiktok')) return <Music2 key={platform} size={12} className="text-cyan-400" />;
    return null;
  };

  return (
    <div className="flex flex-col md:flex-row h-full">
      {/* Sidebar */}
      <div className="w-full md:w-80 border-b md:border-b-0 md:border-r border-white/5 bg-slate-950/30 flex flex-col p-4 md:p-6 overflow-y-auto max-h-[300px] md:max-h-full">
        <h2 className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-500 mb-6 flex items-center justify-between">
          Neural Findings
          <Sparkles size={14} className="text-purple-400" />
        </h2>
        
        <div className="flex md:flex-col gap-3 pb-2 md:pb-0 overflow-x-auto md:overflow-x-visible">
          {clips.map((clip) => (
            <div 
              key={clip.id}
              onClick={() => handleClipSelect(clip)}
              className={`shrink-0 md:shrink-1 w-[240px] md:w-full p-4 rounded-2xl cursor-pointer transition-all border relative overflow-hidden ${
                selectedClip?.id === clip.id 
                ? 'bg-purple-500/10 border-purple-500/30' 
                : 'bg-transparent border-white/5 hover:bg-white/5'
              }`}
            >
              <div className="flex justify-between items-center mb-2">
                <span className="text-[10px] font-mono text-slate-500">00:{Math.floor(clip.startTime)} — 00:{Math.floor(clip.endTime)}</span>
                <div className="text-purple-400 text-[10px] font-bold px-2 py-0.5 rounded-lg bg-purple-500/10 border border-purple-500/20">
                  {clip.viralScore}%
                </div>
              </div>
              <h3 className={`font-bold text-sm mb-3 truncate transition-colors ${selectedClip?.id === clip.id ? 'text-white' : 'text-slate-500'}`}>
                {clip.title}
              </h3>
              <div className="flex items-center justify-between">
                <div className="flex gap-2 items-center">
                  {clip.suggestedPlatforms.slice(0, 3).map(p => renderPlatformIcon(p))}
                </div>
                <ChevronRight size={14} className={`text-purple-400 transition-all ${selectedClip?.id === clip.id ? 'translate-x-0 opacity-100' : '-translate-x-2 opacity-0'}`} />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Workspace */}
      <div className="flex-1 flex flex-col bg-[#020617] overflow-y-auto">
        <div className="p-4 md:p-10 max-w-7xl mx-auto w-full space-y-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 md:gap-10">
            {/* Player & Captions */}
            <div className="lg:col-span-7 space-y-6">
              <div className="relative group aspect-video bg-black rounded-2xl md:rounded-[2rem] overflow-hidden border border-white/5 shadow-2xl">
                <video 
                  ref={videoRef}
                  src={videoUrl}
                  className="w-full h-full object-cover"
                  onPlay={() => setIsPlaying(true)}
                  onPause={() => setIsPlaying(false)}
                />
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 bg-black/40 transition-opacity">
                  <button onClick={togglePlay} className="w-16 h-16 md:w-20 md:h-20 bg-white text-black rounded-full flex items-center justify-center hover:scale-110 active:scale-95 transition-all">
                    {isPlaying ? <Pause size={28} fill="currentColor" /> : <Play size={28} className="ml-1" fill="currentColor" />}
                  </button>
                </div>
              </div>

              {/* AI Captions Module */}
              <div className="glass p-6 md:p-8 rounded-2xl md:rounded-[2.5rem] border border-white/5">
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center gap-3">
                    <MessageSquare size={20} className="text-purple-400" />
                    <h3 className="text-xl font-bold tracking-tight">AI Viral Captions</h3>
                  </div>
                  <button 
                    onClick={handleGenerateCaptions}
                    disabled={isGenerating}
                    className="text-xs font-bold px-4 py-2 bg-purple-500 text-white rounded-full flex items-center gap-2 hover:brightness-110 disabled:opacity-50 transition-all shadow-lg shadow-purple-500/20"
                  >
                    {isGenerating ? <Loader2 size={14} className="animate-spin" /> : <Sparkles size={14} />}
                    {selectedClip?.generatedCaptions ? 'Re-Optimize' : 'Optimize Content'}
                  </button>
                </div>

                <div className="mb-6 space-y-2">
                  <div className="flex items-center gap-2 text-[10px] font-black uppercase text-slate-500 tracking-widest">
                    <Settings2 size={12} />
                    Custom Guidance / Keywords
                  </div>
                  <input 
                    type="text"
                    value={customGuidance}
                    onChange={(e) => setCustomGuidance(e.target.value)}
                    placeholder="E.g. Use a funny tone, include 'Whop', focus on passive income..."
                    className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-xs text-slate-200 placeholder:text-slate-600 focus:outline-none focus:ring-1 ring-purple-500/50 transition-all"
                  />
                </div>

                {selectedClip?.generatedCaptions ? (
                  <div className="space-y-4">
                    <div className="flex gap-2 p-1 bg-white/5 rounded-xl border border-white/5">
                      {(['tiktok', 'reels', 'shorts'] as const).map(tab => (
                        <button
                          key={tab}
                          onClick={() => setActiveTab(tab)}
                          className={`flex-1 py-2 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all ${activeTab === tab ? 'bg-purple-500 text-white shadow-lg' : 'text-slate-500 hover:text-white'}`}
                        >
                          {tab}
                        </button>
                      ))}
                    </div>
                    <div className="p-4 bg-black/40 border border-white/5 rounded-2xl text-sm text-slate-300 leading-relaxed relative group min-h-[80px] animate-in fade-in duration-300">
                      {selectedClip.generatedCaptions[activeTab]}
                      <button 
                        onClick={() => copyToClipboard(selectedClip!.generatedCaptions![activeTab])}
                        className="absolute bottom-3 right-3 p-2 bg-white/10 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity hover:bg-white/20"
                      >
                         <Copy size={14} />
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="py-8 text-center border border-dashed border-white/10 rounded-2xl">
                    <p className="text-xs text-slate-500">Enter keywords above and click optimize to generate viral hooks.</p>
                  </div>
                )}
              </div>
            </div>

            {/* AI Node Details & Viral Pulse */}
            <div className="lg:col-span-5 space-y-6">
               <div className="glass p-6 md:p-8 rounded-2xl md:rounded-[2.5rem] border border-white/5 h-full space-y-8">
                 <div className="flex items-center justify-between">
                   <div className="flex items-center gap-2 text-slate-500">
                     <TrendingUp size={16} />
                     <h4 className="text-[10px] font-black uppercase tracking-widest">Viral Pulse</h4>
                   </div>
                   <button 
                    onClick={handleViralPulse}
                    disabled={isSearching}
                    className="flex items-center gap-2 text-[10px] font-bold text-cyan-400 hover:text-cyan-300 transition-colors"
                   >
                     {isSearching ? <Loader2 size={12} className="animate-spin" /> : <Search size={12} />}
                     Search Live Niche
                   </button>
                 </div>

                 {/* Pulse Insights */}
                 {selectedClip?.nicheInsights ? (
                   <div className="space-y-3">
                     <p className="text-[10px] uppercase font-black text-slate-600 tracking-widest mb-1">Algorithmic Advantage</p>
                     {selectedClip.nicheInsights.map((insight, i) => (
                       <div key={i} className="flex items-start gap-3 p-3 bg-cyan-500/5 rounded-xl border border-cyan-500/10 animate-in fade-in slide-in-from-left-2 duration-300" style={{ animationDelay: `${i * 100}ms` }}>
                         <div className="w-5 h-5 rounded bg-cyan-500/20 flex items-center justify-center shrink-0 mt-0.5">
                           <Zap size={12} className="text-cyan-400" />
                         </div>
                         <p className="text-[11px] text-slate-300 font-medium leading-relaxed">{insight}</p>
                       </div>
                     ))}
                   </div>
                 ) : (
                   <div className="p-10 text-center border border-dashed border-white/10 rounded-2xl">
                      <Target size={32} className="mx-auto text-slate-800 mb-4" />
                      <p className="text-[10px] uppercase font-bold text-slate-600 tracking-widest">Awaiting Pulse Data</p>
                      <button 
                        onClick={handleViralPulse}
                        className="mt-4 text-[10px] font-bold text-cyan-400 hover:underline"
                      >
                        Find Viral Patterns
                      </button>
                   </div>
                 )}

                 <div className="h-px bg-white/5" />

                 <div>
                   <h5 className="text-[10px] font-black uppercase text-slate-500 mb-4 tracking-widest">Vora Transcript</h5>
                   <div className="p-4 bg-black/40 border border-white/5 rounded-xl text-xs text-slate-400 font-mono leading-relaxed h-[140px] md:h-[180px] overflow-y-auto">
                     {selectedClip?.transcript}
                   </div>
                 </div>

                 <div className="flex flex-col gap-3 pt-4">
                    <button 
                      onClick={() => onOpenStrategy(selectedClip!)}
                      className="w-full py-4 bg-white/5 rounded-xl md:rounded-2xl font-bold flex items-center justify-center gap-2 border border-purple-500/20 hover:bg-white/10 transition-all"
                    >
                      <Target size={18} className="text-purple-400" /> Monetization Strategy
                    </button>
                    <button 
                      onClick={() => onExport(selectedClip!)}
                      className="w-full py-4 brand-gradient rounded-xl md:rounded-2xl font-extrabold text-white flex items-center justify-center gap-2 shadow-lg shadow-purple-500/10 hover:brightness-110 active:scale-95 transition-all"
                    >
                      Render for Distribution <Share size={18} />
                    </button>
                 </div>
               </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ClipEditor;
