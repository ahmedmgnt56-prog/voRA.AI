
import React, { useState, useEffect, useRef } from 'react';
import { AppState, Clip, UserTier } from './types';
import VideoUploader from './components/VideoUploader';
import ClipEditor from './components/ClipEditor';
import Pricing from './components/Pricing';
import StrategyLab from './components/StrategyLab';
import { GeminiService } from './services/geminiService';
import { 
  Loader2, AlertCircle, Sparkles, PlusSquare, 
  Film, CreditCard, LogOut, Zap, Crown, Menu, X, BarChart3
} from 'lucide-react';

const App: React.FC = () => {
  const [appState, setAppState] = useState<AppState>(AppState.IDLE);
  const [userTier, setUserTier] = useState<UserTier>(UserTier.FREE);
  const [videoUrl, setVideoUrl] = useState<string>('');
  const [clips, setClClips] = useState<Clip[]>([]);
  const [selectedClip, setSelectedClip] = useState<Clip | null>(null);
  const [loadingMessage, setLoadingMessage] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  const geminiRef = useRef<GeminiService | null>(null);

  useEffect(() => {
    geminiRef.current = new GeminiService();
  }, []);

  const startAnalysis = async (url: string, name: string) => {
    setAppState(AppState.ANALYZING);
    setLoadingMessage("Vora is processing neural nodes...");

    try {
      const mockFrames = ['data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/2wBDAQkJCQwLDBgNDRgyIRwhMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjL/AARCAABAAEDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBEQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZnaGlqc3R1dnd4eXqGhiSLaX5mZmup6qc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD5/ooooA//2Q=='];

      if (geminiRef.current) {
        const analyzedClips = await geminiRef.current.analyzeVideoContent(`${name} (${url})`, mockFrames);
        const limit = userTier === UserTier.FREE ? 1 : analyzedClips.length;
        setClClips(analyzedClips.slice(0, limit));
        setAppState(AppState.EDITING);
      }
    } catch (err) {
      setError("Vora Neural Engine Busy.");
      setAppState(AppState.IDLE);
    }
  };

  const handleUrlSubmit = async (url: string) => {
    setAppState(AppState.UPLOADING);
    setLoadingMessage(`Syncing media...`);
    setTimeout(async () => {
      setVideoUrl("https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4");
      await startAnalysis(url, `Source Stream`);
    }, 1500);
  };

  const renderNavItems = () => (
    <>
      <button 
        onClick={() => { setAppState(AppState.IDLE); setIsSidebarOpen(false); }}
        className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${appState === AppState.IDLE ? 'bg-purple-500/10 text-purple-400 font-bold' : 'text-slate-400 hover:text-white'}`}
      >
        <PlusSquare size={20} />
        <span className="text-sm">New Feed</span>
      </button>
      <button 
        className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${[AppState.EDITING, AppState.STRATEGY].includes(appState) ? 'bg-purple-500/10 text-purple-400 font-bold' : 'text-slate-400 hover:text-white'}`}
        onClick={() => { clips.length > 0 && setAppState(AppState.EDITING); setIsSidebarOpen(false); }}
      >
        <Film size={20} />
        <span className="text-sm">Studio</span>
      </button>
      <button 
        onClick={() => { setAppState(AppState.PRICING); setIsSidebarOpen(false); }}
        className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${appState === AppState.PRICING ? 'bg-purple-500/10 text-purple-400 font-bold' : 'text-slate-400 hover:text-white'}`}
      >
        <CreditCard size={20} />
        <span className="text-sm">Upgrade</span>
      </button>
    </>
  );

  return (
    <div className="flex flex-col md:flex-row min-h-screen bg-[#020617] text-slate-100">
      {/* Mobile Header */}
      <div className="md:hidden flex items-center justify-between p-4 glass border-b border-white/5 sticky top-0 z-50">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 brand-gradient rounded-lg flex items-center justify-center">
            <Zap size={16} fill="white" className="text-white" />
          </div>
          <span className="text-lg font-black tracking-tighter uppercase">VORA</span>
        </div>
        <button onClick={() => setIsSidebarOpen(!isSidebarOpen)} className="p-2 text-slate-400">
          {isSidebarOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Desktop Sidebar */}
      <aside className={`fixed md:relative inset-y-0 left-0 w-64 bg-[#020617] border-r border-white/5 flex flex-col p-6 z-40 transition-transform md:translate-x-0 ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="hidden md:flex items-center gap-3 mb-10">
          <div className="w-10 h-10 brand-gradient rounded-xl flex items-center justify-center shadow-lg shadow-purple-500/20">
            <Zap size={20} fill="white" className="text-white" />
          </div>
          <span className="text-2xl font-black tracking-tighter uppercase">VORA</span>
        </div>

        <nav className="flex-1 space-y-2">
          {renderNavItems()}
        </nav>

        <div className="mt-auto space-y-6">
          {userTier === UserTier.FREE && (
            <div className="p-4 rounded-2xl bg-gradient-to-br from-purple-500/10 to-cyan-500/5 border border-white/5">
              <div className="flex items-center gap-2 text-purple-400 font-bold text-[10px] uppercase tracking-widest mb-2">
                <Crown size={12} /> Free Member
              </div>
              <p className="text-[10px] text-slate-500 mb-3">Scale with Vora Pro for unlimited neural clipping.</p>
              <button onClick={() => setAppState(AppState.PRICING)} className="w-full py-2 bg-white text-black rounded-lg text-xs font-bold hover:brightness-110">Get Pro</button>
            </div>
          )}
          <div className="flex items-center gap-3 p-2 hover:bg-white/5 rounded-xl transition-all cursor-pointer">
            <div className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center text-[10px] font-bold">VX</div>
            <div className="flex-1 overflow-hidden">
              <p className="text-xs font-bold truncate">Neural Account</p>
              <p className="text-[10px] text-slate-500 truncate">vora.ai/alpha</p>
            </div>
            <LogOut size={14} className="text-slate-500" />
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 relative flex flex-col overflow-x-hidden">
        <div className="flex-1 overflow-y-auto pb-20 md:pb-0">
          {appState === AppState.IDLE && (
            <VideoUploader onUpload={(f) => handleUrlSubmit(f.name)} onUrlSubmit={handleUrlSubmit} />
          )}

          {appState === AppState.PRICING && (
            <Pricing currentTier={userTier} onUpgrade={(t) => { setUserTier(t); setAppState(AppState.IDLE); }} />
          )}

          {(appState === AppState.ANALYZING || appState === AppState.UPLOADING) && (
            <div className="flex flex-col items-center justify-center h-full space-y-8 px-6 text-center">
              <div className="relative">
                <div className="w-24 h-24 md:w-32 md:h-32 rounded-full border-4 border-slate-900 border-t-purple-500 animate-spin" />
                <div className="absolute inset-0 flex items-center justify-center">
                  <Sparkles className="text-purple-500 animate-pulse" size={32} />
                </div>
              </div>
              <div>
                <h2 className="text-2xl md:text-3xl font-bold mb-3">{loadingMessage}</h2>
                <p className="text-slate-500 text-sm max-w-xs mx-auto">Vora's neural engine is identifying high-velocity hooks.</p>
              </div>
            </div>
          )}

          {appState === AppState.EDITING && (
            <ClipEditor 
              videoUrl={videoUrl} 
              clips={clips} 
              onExport={() => setAppState(AppState.EXPORTING)} 
              onOpenStrategy={(c) => { setSelectedClip(c); setAppState(AppState.STRATEGY); }}
            />
          )}

          {appState === AppState.STRATEGY && selectedClip && (
            <StrategyLab clip={selectedClip} onBack={() => setAppState(AppState.EDITING)} />
          )}
        </div>

        {/* Mobile Bottom Nav */}
        <nav className="md:hidden fixed bottom-0 inset-x-0 glass border-t border-white/5 p-2 flex justify-around items-center mobile-safe-area z-50">
          <button onClick={() => setAppState(AppState.IDLE)} className={`p-3 rounded-xl ${appState === AppState.IDLE ? 'text-purple-400 bg-purple-500/10' : 'text-slate-500'}`}><PlusSquare size={20} /></button>
          <button onClick={() => clips.length > 0 && setAppState(AppState.EDITING)} className={`p-3 rounded-xl ${appState === AppState.EDITING ? 'text-purple-400 bg-purple-500/10' : 'text-slate-500'}`}><Film size={20} /></button>
          <button onClick={() => setAppState(AppState.PRICING)} className={`p-3 rounded-xl ${appState === AppState.PRICING ? 'text-purple-400 bg-purple-500/10' : 'text-slate-500'}`}><CreditCard size={20} /></button>
          <button className="p-3 text-slate-500"><BarChart3 size={20} /></button>
        </nav>
      </main>

      {/* Export Overlay */}
      {appState === AppState.EXPORTING && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-xl flex items-center justify-center z-[100] px-6">
          <div className="bg-slate-950 p-8 md:p-12 rounded-[2.5rem] border border-white/10 text-center max-w-sm w-full">
            <Loader2 className="animate-spin text-purple-500 mx-auto mb-8" size={48} />
            <h3 className="text-2xl font-bold mb-3">Syncing Virality</h3>
            <p className="text-slate-400 text-sm">Embedding hooks and standardizing resolution for the algorithm...</p>
            <button onClick={() => setAppState(AppState.EDITING)} className="mt-8 text-sm text-slate-600 hover:text-white underline">Cancel</button>
          </div>
        </div>
      )}

      {error && (
        <div className="fixed bottom-24 md:bottom-10 right-4 md:right-10 glass border border-red-500/50 text-red-400 p-4 md:p-6 rounded-2xl md:rounded-[2rem] flex items-center gap-4 animate-in slide-in-from-right z-50 max-w-[calc(100vw-2rem)]">
          <AlertCircle size={24} className="shrink-0" />
          <span className="font-semibold text-sm">{error}</span>
          <button onClick={() => setError(null)} className="ml-2 text-slate-500">&times;</button>
        </div>
      )}
    </div>
  );
};

export default App;
