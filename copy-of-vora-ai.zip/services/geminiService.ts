
import { GoogleGenAI, Type, GenerateContentResponse } from "@google/genai";
import { Clip } from "../types";

export class GeminiService {
  private ai: GoogleGenAI;

  constructor() {
    this.ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  }

  async analyzeVideoContent(videoName: string, frames: string[]): Promise<Clip[]> {
    const prompt = `
      You are Vora, an elite AI viral content strategist. 
      Analyze these frames from the video "${videoName}". 
      Extract 3 moments with the highest retention potential. 
      For each clip, provide:
      1. A viral hook title.
      2. A core summary of the value proposition.
      3. A "viral score" (0-100) based on social media algorithms.
      4. Exact start and end timestamps (estimated from content flow).
      5. Primary target platforms (YouTube, Instagram, TikTok).
      
      Focus on rapid transitions, strong hooks, and polarizing or highly educational insights.
    `;

    const parts = [
      { text: prompt },
      ...frames.map(f => ({
        inlineData: {
          mimeType: "image/jpeg",
          data: f.split(',')[1]
        }
      }))
    ];

    try {
      const response: GenerateContentResponse = await this.ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: { parts },
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                title: { type: Type.STRING },
                description: { type: Type.STRING },
                viralScore: { type: Type.NUMBER },
                startTime: { type: Type.NUMBER },
                endTime: { type: Type.NUMBER },
                suggestedPlatforms: { 
                  type: Type.ARRAY,
                  items: { type: Type.STRING }
                },
                transcript: { type: Type.STRING }
              },
              required: ["title", "description", "viralScore", "startTime", "endTime"]
            }
          }
        }
      });

      const text = response.text || "[]";
      const clips: Clip[] = JSON.parse(text);
      return clips.map((c, i) => ({ ...c, id: `clip-${i}` }));
    } catch (error) {
      console.error("Vora Neural Error:", error);
      throw error;
    }
  }

  async searchViralNiche(clipTitle: string, description: string): Promise<{ insights: string[], sources: string[] }> {
    const prompt = `Search for viral video trends, high-performing hooks, and current editing styles in the niche of: "${clipTitle}". Context: ${description}. 
    Identify specifically what makes videos go viral in this niche right now (e.g. "fast text overlays", "controversial questions", "split screen with ASMR"). 
    Also find 3-5 high-performing keywords/hashtags.`;
    
    try {
      const response = await this.ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt,
        config: {
          tools: [{ googleSearch: {} }]
        }
      });

      const insights = response.text?.split('\n').filter(l => l.trim().length > 10).slice(0, 4) || [];
      const sources = response.candidates?.[0]?.groundingMetadata?.groundingChunks?.map(c => c.web?.uri).filter(Boolean) as string[] || [];
      
      return { insights, sources };
    } catch (error) {
      console.error("Viral Pulse Error:", error);
      return { insights: ["Use 1.5x speed narration", "High-contrast yellow captions", "Loop the last 2 seconds"], sources: [] };
    }
  }

  async generateOptimizedCaptions(clip: Clip, trends: string[], customGuidance?: string): Promise<Record<string, string>> {
    const trendCtx = trends.join(". ");
    const guidancePart = customGuidance ? `IMPORTANT - Incorporate these custom keywords/directions: "${customGuidance}"` : "";
    const prompt = `
      You are Vora AI, an expert copywriter for viral social media content. Generate platform-specific viral captions for the clip: "${clip.title}".
      Context: ${clip.description}.
      Current Viral Trends to leverage: ${trendCtx}.
      ${guidancePart}
      
      Generate 3 distinct captions:
      1. TikTok: High energy, lots of emojis, strong polarizing hook.
      2. Instagram: Aesthetic, value-driven, community-focused CTA.
      3. YouTube Shorts: Benefit-heavy, SEO optimized, short and punchy.
      
      Return as a JSON object with keys: tiktok, reels, shorts.
    `;

    try {
      const response = await this.ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              tiktok: { type: Type.STRING },
              reels: { type: Type.STRING },
              shorts: { type: Type.STRING }
            },
            required: ["tiktok", "reels", "shorts"]
          }
        }
      });

      return JSON.parse(response.text || "{}");
    } catch (error) {
      console.error("Caption Generation Error:", error);
      return {
        tiktok: "You NEED to see this! 🤯 #viral #foryou",
        reels: "This changed everything. ✨ Check the bio.",
        shorts: "The Secret Revealed. 📈 Watch now."
      };
    }
  }
}
