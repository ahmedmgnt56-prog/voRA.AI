
export interface Clip {
  id: string;
  startTime: number;
  endTime: number;
  title: string;
  description: string;
  viralScore: number;
  transcript: string;
  suggestedPlatforms: string[];
  nicheInsights?: string[];
  generatedCaptions?: Record<string, string>;
}

export enum UserTier {
  FREE = 'FREE',
  PRO = 'PRO',
  ENTERPRISE = 'ENTERPRISE'
}

export enum AppState {
  IDLE = 'IDLE',
  UPLOADING = 'UPLOADING',
  ANALYZING = 'ANALYZING',
  EDITING = 'EDITING',
  EXPORTING = 'EXPORTING',
  PRICING = 'PRICING',
  STRATEGY = 'STRATEGY'
}
